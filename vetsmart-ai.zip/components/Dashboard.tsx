import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { Activity, Users, AlertCircle, TrendingUp, Calendar, ArrowLeft, CheckCircle, Plus, Trash2, Sun, CloudRain, Wind } from 'lucide-react';
import { AppView } from '../types';

interface DashboardProps {
  onGoBack: () => void;
  onChangeView: (view: AppView) => void;
}

const mockHealthData = [
  { name: 'Sog\'lom', value: 85 },
  { name: 'Davolanmoqda', value: 10 },
  { name: 'Kasal', value: 5 },
];

const mockActivityData = [
  { name: 'Dush', consults: 4, alerts: 1 },
  { name: 'Sesh', consults: 3, alerts: 0 },
  { name: 'Chor', consults: 7, alerts: 2 },
  { name: 'Pay', consults: 2, alerts: 0 },
  { name: 'Juma', consults: 5, alerts: 1 },
  { name: 'Shan', consults: 6, alerts: 3 },
  { name: 'Yak', consults: 4, alerts: 0 },
];

const COLORS = ['#22c55e', '#f59e0b', '#ef4444'];

interface Task {
  id: number;
  text: string;
  time: string;
  done: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ onGoBack, onChangeView }) => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, text: "Sigir #124 (Masha) ni ko'rikdan o'tkazish", time: "Bugun, 14:00", done: false },
    { id: 2, text: "Yangi ozuqa buyurtma qilish", time: "Ertaga", done: false },
    { id: 3, text: "Dr. Aliyev bilan video uchrashuv", time: "Bugun, 16:30", done: true },
  ]);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskText, setNewTaskText] = useState("");

  const toggleTask = (id: number) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const deleteTask = (id: number) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask: Task = {
      id: Date.now(),
      text: newTaskText,
      time: 'Yangi',
      done: false
    };
    setTasks([newTask, ...tasks]);
    setNewTaskText("");
    setIsAddingTask(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onGoBack}
            className="p-2 rounded-full hover:bg-gray-200 transition-colors bg-white shadow-sm border border-gray-200"
            title="Asosiy sahifaga qaytish"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Ferma Ko'rsatkichlari</h1>
            <p className="text-gray-500">Bugungi holat bo'yicha umumiy hisobot</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
           <div className="hidden md:flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-lg border border-blue-100">
              <Sun className="h-5 w-5 text-yellow-500" />
              <span className="font-bold text-sm">24°C</span>
              <span className="text-xs text-blue-500">Quyoshli</span>
           </div>
           <div className="bg-primary-100 text-primary-800 px-4 py-2 rounded-lg font-medium text-sm">
             Obuna: Premium (Fermer)
           </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div 
          onClick={() => onChangeView(AppView.PASSPORT)}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-all group"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Jami Hayvonlar</h3>
            <div className="p-2 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
              <Activity className="h-5 w-5 text-blue-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900">124</div>
          <p className="text-green-600 text-xs flex items-center mt-2">
            <TrendingUp className="h-3 w-3 mr-1" />
            +4 o'tgan oyga nisbatan
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-all">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Kasal (Xavf ostida)</h3>
            <div className="p-2 bg-red-50 rounded-lg">
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900">5</div>
          <p className="text-red-600 text-xs mt-2">Zudlik bilan e'tibor talab qiladi</p>
        </div>

        <div 
          onClick={() => onChangeView(AppView.VETS)}
          className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-all group"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Onlayn Veterinarlar</h3>
            <div className="p-2 bg-green-50 rounded-lg group-hover:bg-green-100 transition-colors">
              <Users className="h-5 w-5 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900">12</div>
          <p className="text-gray-400 text-xs mt-2">Hozir aloqada</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-center mb-4">
             <h3 className="text-gray-500 text-sm font-medium">Keyingi Emlash</h3>
             <div className="p-2 bg-purple-50 rounded-lg">
               <Calendar className="h-5 w-5 text-purple-600" />
             </div>
          </div>
          <div className="text-lg font-bold text-gray-900">14 Mart, 2024</div>
          <p className="text-gray-400 text-xs mt-2">Qoramol - Oqsil kasalligi</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activity Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Haftalik Faollik</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockActivityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend />
                <Bar dataKey="consults" name="Konsultatsiyalar" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="alerts" name="Xavf signallari" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Health Status Pie Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Salomatlik Holati</h3>
          <div className="h-64 flex items-center justify-center">
             <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={mockHealthData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {mockHealthData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" verticalAlign="middle" align="right" />
              </PieChart>
             </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Task List */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
         <div className="flex justify-between items-center mb-4">
           <h3 className="text-lg font-bold text-gray-900">Bajariladigan Ishlar (Tasks)</h3>
           <button 
             onClick={() => setIsAddingTask(true)}
             className="bg-primary-600 text-white p-2 rounded-lg hover:bg-primary-700 transition-colors shadow-sm"
           >
             <Plus className="h-4 w-4" />
           </button>
         </div>

         {isAddingTask && (
           <form onSubmit={addTask} className="mb-4 flex gap-2 animate-fadeIn">
             <input 
               type="text" 
               autoFocus
               value={newTaskText}
               onChange={(e) => setNewTaskText(e.target.value)}
               placeholder="Yangi vazifa..."
               className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500 outline-none"
             />
             <button 
               type="submit" 
               className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700"
             >
               Qo'shish
             </button>
             <button 
               type="button" 
               onClick={() => setIsAddingTask(false)}
               className="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200"
             >
               Bekor
             </button>
           </form>
         )}

         <div className="space-y-3">
            {tasks.length === 0 ? (
              <p className="text-gray-400 text-center py-4">Vazifalar yo'q</p>
            ) : tasks.map(task => (
               <div key={task.id} className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors border border-gray-50 group">
                  <button 
                    onClick={() => toggleTask(task.id)}
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${task.done ? 'bg-green-500 border-green-500' : 'border-gray-300 hover:border-green-400'}`}
                  >
                     {task.done && <CheckCircle className="h-3 w-3 text-white" />}
                  </button>
                  <div className="flex-1 cursor-pointer" onClick={() => toggleTask(task.id)}>
                     <p className={`font-medium transition-all ${task.done ? 'text-gray-400 line-through' : 'text-gray-800'}`}>{task.text}</p>
                     <p className="text-xs text-gray-400">{task.time}</p>
                  </div>
                  <button 
                    onClick={() => deleteTask(task.id)}
                    className="text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
               </div>
            ))}
         </div>
      </div>
    </div>
  );
};

export default Dashboard;