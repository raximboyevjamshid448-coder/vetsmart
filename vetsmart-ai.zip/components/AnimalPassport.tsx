import React, { useState } from 'react';
import { QrCode, Smartphone, Syringe, FileText, X, Check, ArrowLeft, Plus } from 'lucide-react';
import { Animal, AnimalType } from '../types';

interface AnimalPassportProps {
  onGoBack: () => void;
}

// Mock Data
const MOCK_ANIMALS: Animal[] = [
  {
    id: 'A001',
    nfcId: 'NFC-8821',
    name: 'Masha',
    type: AnimalType.CATTLE,
    breed: 'Golshteyn',
    age: '4 yosh',
    weight: '650 kg',
    image: 'https://picsum.photos/seed/cow1/400/300',
    owner: 'Ferma #1',
    status: 'Sog\'lom',
    vaccines: [
      { name: 'Oqsil kasalligi', date: '2023-10-12', nextDueDate: '2024-10-12' },
      { name: 'Quturish', date: '2024-01-15', nextDueDate: '2025-01-15' }
    ],
    history: [
      { date: '2024-02-01', diagnosis: 'Yengil shamollash', treatment: 'Vitamin kompleksi', vetName: 'Dr. Azizov' }
    ]
  },
  {
    id: 'A002',
    nfcId: 'NFC-9943',
    name: 'Rex',
    type: AnimalType.DOG,
    breed: 'Nemis Ovcharkasi',
    age: '2 yosh',
    weight: '32 kg',
    image: 'https://picsum.photos/seed/dog1/400/300',
    owner: 'Alijon',
    status: 'Davolanmoqda',
    vaccines: [
      { name: 'Quturish', date: '2023-05-20', nextDueDate: '2024-05-20' }
    ],
    history: [
      { date: '2024-05-10', diagnosis: 'Oyoq jarohati', treatment: 'Bog\'lash va og\'riq qoldiruvchi', vetName: 'Dr. Karimov' }
    ]
  }
];

const AnimalPassport: React.FC<AnimalPassportProps> = ({ onGoBack }) => {
  const [animals, setAnimals] = useState<Animal[]>(MOCK_ANIMALS);
  const [isScanning, setIsScanning] = useState(false);
  const [scannedAnimal, setScannedAnimal] = useState<Animal | null>(null);
  const [showModal, setShowModal] = useState(false);
  
  // Add Animal Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newAnimalName, setNewAnimalName] = useState('');
  const [newAnimalType, setNewAnimalType] = useState<AnimalType>(AnimalType.CATTLE);

  const startScan = () => {
    setIsScanning(true);
    setShowModal(true);
    setScannedAnimal(null);

    // Simulate scanning process
    setTimeout(() => {
      setIsScanning(false);
      // Randomly pick an animal for demo purposes
      const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
      setScannedAnimal(randomAnimal);
    }, 2000);
  };

  const closeModal = () => {
    setShowModal(false);
    setScannedAnimal(null);
  };

  const handleAddAnimal = (e: React.FormEvent) => {
    e.preventDefault();
    const newAnimal: Animal = {
      id: `A00${animals.length + 1}`,
      nfcId: `NFC-${Math.floor(Math.random() * 10000)}`,
      name: newAnimalName,
      type: newAnimalType,
      breed: 'Noma\'lum',
      age: '1 yosh',
      weight: '---',
      image: `https://picsum.photos/seed/${newAnimalName}/400/300`,
      owner: 'Mening Fermam',
      status: 'Sog\'lom',
      vaccines: [],
      history: []
    };
    setAnimals([...animals, newAnimal]);
    setIsAddModalOpen(false);
    setNewAnimalName('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onGoBack} 
            className="p-2 rounded-full hover:bg-gray-200 transition-colors bg-white shadow-sm border border-gray-200"
            title="Orqaga"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Raqamli Pasport & NFC</h1>
            <p className="text-gray-500">Hayvonlarning to'liq tibbiy tarixi bir joyda</p>
          </div>
        </div>
        <button 
          onClick={() => setIsAddModalOpen(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-600/20"
        >
           <Plus className="h-5 w-5" />
           Hayvon qo'shish
        </button>
      </div>

      {/* Main Scan Action */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
        <div className="space-y-4 max-w-lg">
          <h2 className="text-3xl font-bold">Bir teginish orqali ma'lumot oling</h2>
          <p className="text-blue-100 text-lg">
            NFC texnologiyasi yordamida hayvonning tibbiy kartasini soniyalar ichida oching.
            Qog'ozbozlikka chek qo'ying.
          </p>
          <button 
            onClick={startScan}
            className="bg-white text-blue-600 font-bold py-3 px-8 rounded-full flex items-center gap-2 hover:bg-gray-100 transition-colors shadow-lg"
          >
            <Smartphone className="h-5 w-5" />
            NFC Skanerlash
          </button>
        </div>
        <div className="bg-white/10 p-6 rounded-full backdrop-blur-sm border border-white/20">
          <QrCode className="h-32 w-32 text-white" />
        </div>
      </div>

      {/* Search / Manual List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Ro'yxatdagi Hayvonlar</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 text-sm">
                <th className="pb-3 font-medium">Hayvon</th>
                <th className="pb-3 font-medium">ID / NFC</th>
                <th className="pb-3 font-medium">Egasi</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Harakat</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {animals.map(animal => (
                <tr key={animal.id} className="group hover:bg-gray-50 transition-colors">
                  <td className="py-4">
                    <div className="flex items-center gap-3">
                      <img src={animal.image} alt={animal.name} className="w-10 h-10 rounded-full object-cover" />
                      <div>
                        <div className="font-bold text-gray-900">{animal.name}</div>
                        <div className="text-xs text-gray-500">{animal.breed} ({animal.age})</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 text-sm text-gray-600">
                    <div>{animal.id}</div>
                    <div className="text-xs text-gray-400">{animal.nfcId}</div>
                  </td>
                  <td className="py-4 text-sm text-gray-600">{animal.owner}</td>
                  <td className="py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                      animal.status === 'Sog\'lom' ? 'bg-green-100 text-green-700' :
                      animal.status === 'Kasal' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {animal.status}
                    </span>
                  </td>
                  <td className="py-4">
                    <button 
                      onClick={() => { setScannedAnimal(animal); setShowModal(true); }}
                      className="text-primary-600 font-medium hover:underline"
                    >
                      Pasportni ochish
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Adding Animal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-gray-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
           <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl p-6">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-lg font-bold">Yangi Hayvon</h3>
                 <button onClick={() => setIsAddModalOpen(false)}><X className="h-5 w-5" /></button>
              </div>
              <form onSubmit={handleAddAnimal}>
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Laqabi (Ismi)</label>
                    <input 
                      type="text" 
                      required
                      value={newAnimalName}
                      onChange={(e) => setNewAnimalName(e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none" 
                    />
                 </div>
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Turi</label>
                    <select 
                       value={newAnimalType}
                       onChange={(e) => setNewAnimalType(e.target.value as AnimalType)}
                       className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                    >
                       {Object.values(AnimalType).map(t => (
                          <option key={t} value={t}>{t}</option>
                       ))}
                    </select>
                 </div>
                 <button type="submit" className="w-full bg-green-600 text-white py-2 rounded-lg font-bold hover:bg-green-700">
                    Saqlash
                 </button>
              </form>
           </div>
        </div>
      )}

      {/* Modal for Passport */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
            <button onClick={closeModal} className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full hover:bg-gray-200 z-10">
              <X className="h-5 w-5 text-gray-600" />
            </button>

            {isScanning ? (
              <div className="flex flex-col items-center justify-center p-12 space-y-4 h-96">
                <div className="relative">
                   <div className="absolute inset-0 bg-primary-500 rounded-full animate-ping opacity-20"></div>
                   <Smartphone className="h-16 w-16 text-primary-600 relative z-10 animate-pulse" />
                </div>
                <p className="text-lg font-bold text-gray-800">NFC Teg qidirilmoqda...</p>
                <p className="text-sm text-gray-500">Telefoningizni hayvon qulog'idagi tegga yaqinlashtiring.</p>
              </div>
            ) : scannedAnimal ? (
              <div className="flex flex-col h-full">
                <div className="h-40 bg-gray-200 relative">
                  <img src={scannedAnimal.image} alt={scannedAnimal.name} className="w-full h-full object-cover" />
                  <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/70 to-transparent p-4">
                    <h2 className="text-2xl font-bold text-white">{scannedAnimal.name}</h2>
                    <p className="text-white/80">{scannedAnimal.breed} | {scannedAnimal.age}</p>
                  </div>
                </div>

                <div className="p-6 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <p className="text-xs text-gray-500">Vazni</p>
                      <p className="font-bold text-gray-800">{scannedAnimal.weight}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <p className="text-xs text-gray-500">Egasining ismi</p>
                      <p className="font-bold text-gray-800">{scannedAnimal.owner}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <p className="text-xs text-gray-500">ID Raqam</p>
                      <p className="font-bold text-gray-800">{scannedAnimal.id}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <p className="text-xs text-gray-500">Status</p>
                      <p className={`font-bold ${
                        scannedAnimal.status === 'Sog\'lom' ? 'text-green-600' : 'text-yellow-600'
                      }`}>{scannedAnimal.status}</p>
                    </div>
                  </div>

                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Syringe className="h-5 w-5 text-primary-600" />
                    Emlash Tarixi
                  </h3>
                  <div className="space-y-3 mb-6">
                    {scannedAnimal.vaccines.map((v, i) => (
                      <div key={i} className="flex items-center justify-between p-3 border border-gray-100 rounded-lg bg-green-50/50">
                        <div>
                          <p className="font-bold text-gray-800">{v.name}</p>
                          <p className="text-xs text-gray-500">Qilingan sana: {v.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-semibold text-primary-600">Keyingi:</p>
                          <p className="text-sm font-bold text-gray-700">{v.nextDueDate}</p>
                        </div>
                      </div>
                    ))}
                    {scannedAnimal.vaccines.length === 0 && (
                       <p className="text-sm text-gray-500 italic">Emlash tarixi yo'q.</p>
                    )}
                  </div>

                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <FileText className="h-5 w-5 text-blue-600" />
                    Kasallik Tarixi
                  </h3>
                  <div className="space-y-3">
                    {scannedAnimal.history.map((h, i) => (
                      <div key={i} className="p-3 border border-gray-100 rounded-lg">
                        <div className="flex justify-between mb-1">
                          <p className="font-bold text-gray-800">{h.diagnosis}</p>
                          <p className="text-xs text-gray-500">{h.date}</p>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">Davolash: {h.treatment}</p>
                        <p className="text-xs text-blue-600 flex items-center gap-1">
                           <Check className="h-3 w-3" />
                           {h.vetName}
                        </p>
                      </div>
                    ))}
                    {scannedAnimal.history.length === 0 && (
                      <p className="text-sm text-gray-500 italic">Kasallik tarixi topilmadi.</p>
                    )}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};

export default AnimalPassport;