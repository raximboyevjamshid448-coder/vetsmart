
import React, { useState } from 'react';
import { ShoppingBag, Search, Filter, Plus, ShoppingCart, ArrowLeft, X, Package, Truck, CheckCircle, Clock, Calendar, Minus, Trash2, CreditCard, Banknote } from 'lucide-react';
import { Product } from '../types';

interface MarketplaceProps {
  onGoBack: () => void;
}

interface OrderItem {
  name: string;
  quantity: number;
  price: string;
}

interface Order {
  id: string;
  date: string;
  status: 'pending' | 'shipping' | 'completed' | 'cancelled';
  total: string;
  items: OrderItem[];
  paymentMethod?: string;
}

interface CartItem {
  product: Product;
  quantity: number;
}

const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'VetSmart NFC Teg',
    category: 'Device',
    price: '25,000 UZS',
    image: 'https://picsum.photos/seed/tag/300/300',
    description: "Hayvonlarni identifikatsiya qilish va pasportini saqlash uchun maxsus chip."
  },
  {
    id: '2',
    name: 'Premium Ozuqa (Qoramol)',
    category: 'Feed',
    price: '150,000 UZS',
    image: 'https://picsum.photos/seed/feed/300/300',
    description: "Sut berish hajmini oshiruvchi vitaminlarga boy ozuqa, 20kg."
  },
  {
    id: '3',
    name: 'Albendazol 10%',
    category: 'Medicine',
    price: '45,000 UZS',
    image: 'https://picsum.photos/seed/med1/300/300',
    description: "Gijja va parazitlarga qarshi samarali vosita. 100ml."
  },
  {
    id: '4',
    name: 'Vitamin Complex Pro',
    category: 'Medicine',
    price: '80,000 UZS',
    image: 'https://picsum.photos/seed/vit/300/300',
    description: "Immunitetni mustahkamlovchi inyeksiya."
  },
  {
    id: '5',
    name: 'VetSmart NFC Scanner',
    category: 'Device',
    price: '450,000 UZS',
    image: 'https://picsum.photos/seed/scanner/300/300',
    description: "Professional NFC o'quvchi qurilma (katta fermalar uchun)."
  }
];

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-7782',
    date: 'Bugun, 10:30',
    status: 'shipping',
    total: '175,000 UZS',
    items: [
      { name: 'Premium Ozuqa (Qoramol)', quantity: 1, price: '150,000 UZS' },
      { name: 'VetSmart NFC Teg', quantity: 1, price: '25,000 UZS' }
    ],
    paymentMethod: 'Click'
  },
  {
    id: 'ORD-7781',
    date: 'Kecha, 14:20',
    status: 'pending',
    total: '45,000 UZS',
    items: [
      { name: 'Albendazol 10%', quantity: 1, price: '45,000 UZS' }
    ],
    paymentMethod: 'Naqd'
  },
  {
    id: 'ORD-7705',
    date: '10 Mart, 2024',
    status: 'completed',
    total: '450,000 UZS',
    items: [
      { name: 'VetSmart NFC Scanner', quantity: 1, price: '450,000 UZS' }
    ],
    paymentMethod: 'Payme'
  },
  {
    id: 'ORD-7650',
    date: '1 Mart, 2024',
    status: 'completed',
    total: '100,000 UZS',
    items: [
      { name: 'VetSmart NFC Teg', quantity: 4, price: '25,000 UZS' }
    ],
    paymentMethod: 'Click'
  }
];

const Marketplace: React.FC<MarketplaceProps> = ({ onGoBack }) => {
  const [category, setCategory] = useState<string>('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  
  // UI States
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orderTab, setOrderTab] = useState<'active' | 'history'>('active');
  const [paymentMethod, setPaymentMethod] = useState<'Naqd' | 'Click' | 'Payme'>('Click');

  const filteredProducts = category === 'All' 
    ? MOCK_PRODUCTS 
    : MOCK_PRODUCTS.filter(p => p.category === category);

  const activeOrders = orders.filter(o => o.status === 'pending' || o.status === 'shipping');
  const historyOrders = orders.filter(o => o.status === 'completed' || o.status === 'cancelled');

  // Helpers
  const parsePrice = (str: string) => parseInt(str.replace(/[^0-9]/g, ''), 10);
  const formatPrice = (num: number) => num.toLocaleString('en-US').replace(/,/g, ' ') + ' UZS';

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }));
  };

  const cartTotalAmount = cart.reduce((sum, item) => sum + (parsePrice(item.product.price) * item.quantity), 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;

    const newOrder: Order = {
      id: `ORD-${Math.floor(Math.random() * 9000) + 1000}`,
      date: 'Hozirgina',
      status: 'pending',
      total: formatPrice(cartTotalAmount),
      items: cart.map(c => ({
        name: c.product.name,
        quantity: c.quantity,
        price: c.product.price
      })),
      paymentMethod: paymentMethod
    };

    setOrders([newOrder, ...orders]);
    setCart([]);
    setIsCartOpen(false);
    setIsOrdersOpen(true);
    setOrderTab('active');
  };

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'shipping':
        return <span className="flex items-center gap-1 bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold"><Truck className="h-3 w-3" /> Yetkazilmoqda</span>;
      case 'pending':
        return <span className="flex items-center gap-1 bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs font-bold"><Clock className="h-3 w-3" /> Tayyorlanmoqda</span>;
      case 'completed':
        return <span className="flex items-center gap-1 bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold"><CheckCircle className="h-3 w-3" /> Yetkazib berildi</span>;
      default:
        return <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-bold">Bekor qilingan</span>;
    }
  };

  return (
    <div className="space-y-6 relative">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <button 
            onClick={onGoBack} 
            className="p-2 rounded-full hover:bg-gray-200 transition-colors bg-white shadow-sm border border-gray-200"
            title="Orqaga"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">VetSmart Do'kon</h1>
            <p className="text-gray-500">NFC teglar, dori-darmon va ozuqa mahsulotlari</p>
          </div>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="relative">
             <button 
                onClick={() => setIsCartOpen(true)}
                className="p-3 bg-white hover:bg-gray-50 text-gray-700 rounded-xl border border-gray-200 shadow-sm relative transition-colors"
             >
                <ShoppingCart className="h-6 w-6" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center animate-bounce">
                    {cartItemCount}
                  </span>
                )}
             </button>
          </div>
          <button 
            onClick={() => setIsOrdersOpen(true)}
            className="bg-primary-600 text-white px-4 py-3 rounded-xl font-medium hover:bg-primary-700 transition-colors flex items-center gap-2 shadow-lg shadow-primary-500/30 active:scale-95"
          >
            <Package className="h-5 w-5" />
            Buyurtmalarim
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Mahsulot qidirish..." 
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
          {['All', 'Device', 'Medicine', 'Feed'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap text-sm font-medium transition-colors ${
                category === cat 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat === 'All' ? 'Barchasi' : cat === 'Device' ? 'Qurilmalar' : cat === 'Medicine' ? 'Dorilar' : 'Ozuqa'}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all flex flex-col group">
            <div className="h-48 relative bg-gray-100 overflow-hidden">
               <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
               <span className="absolute top-2 right-2 bg-white/90 backdrop-blur text-xs font-bold px-2 py-1 rounded text-gray-700">
                 {product.category === 'Device' ? 'Qurilma' : product.category === 'Medicine' ? 'Dori' : 'Ozuqa'}
               </span>
            </div>
            <div className="p-4 flex-1 flex flex-col">
              <h3 className="font-bold text-gray-900 mb-1">{product.name}</h3>
              <p className="text-sm text-gray-500 mb-4 line-clamp-2 flex-1">{product.description}</p>
              
              <div className="flex justify-between items-center mt-auto">
                <span className="font-bold text-primary-700 text-lg">{product.price}</span>
                <button 
                  onClick={() => addToCart(product)}
                  className="bg-gray-900 text-white p-2 rounded-lg hover:bg-gray-800 transition-colors active:scale-95 shadow-md"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Orders Modal */}
      {isOrdersOpen && (
        <div className="fixed inset-0 bg-gray-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-lg h-[80vh] flex flex-col shadow-2xl animate-fadeIn">
            {/* Modal Header */}
            <div className="p-4 border-b border-gray-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Package className="h-5 w-5 text-primary-600" />
                Buyurtmalarim
              </h2>
              <button 
                onClick={() => setIsOrdersOpen(false)}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="h-6 w-6 text-gray-500" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-gray-100">
              <button 
                onClick={() => setOrderTab('active')}
                className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${
                  orderTab === 'active' 
                    ? 'border-primary-500 text-primary-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Joriy Buyurtmalar
              </button>
              <button 
                onClick={() => setOrderTab('history')}
                className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${
                  orderTab === 'history' 
                    ? 'border-primary-500 text-primary-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Buyurtma Tarixi
              </button>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {(orderTab === 'active' ? activeOrders : historyOrders).length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-400">
                  <Package className="h-16 w-16 mb-2 opacity-20" />
                  <p>Hozircha buyurtmalar yo'q</p>
                </div>
              ) : (
                (orderTab === 'active' ? activeOrders : historyOrders).map(order => (
                  <div key={order.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="font-bold text-gray-900">{order.id}</div>
                        <div className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                          <Calendar className="h-3 w-3" />
                          {order.date}
                        </div>
                      </div>
                      {getStatusBadge(order.status)}
                    </div>
                    
                    <div className="space-y-2 mb-3 border-t border-b border-gray-50 py-3">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm">
                          <span className="text-gray-600">
                            {item.quantity}x {item.name}
                          </span>
                          <span className="font-medium text-gray-900">{item.price}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between items-center pt-2">
                       <div className="flex flex-col">
                          <span className="text-xs text-gray-500">To'lov turi:</span>
                          <span className="font-medium text-sm text-gray-800">{order.paymentMethod || 'Naqd'}</span>
                       </div>
                      <div className="text-right">
                        <span className="text-sm text-gray-500">Jami:</span>
                        <div className="font-bold text-lg text-primary-700">{order.total}</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Cart Modal */}
      {isCartOpen && (
         <div className="fixed inset-0 bg-gray-900/50 z-50 flex items-center justify-end backdrop-blur-sm">
            <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col animate-slideLeft">
               <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                  <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                     <ShoppingCart className="h-5 w-5 text-primary-600" />
                     Savat
                  </h2>
                  <button 
                     onClick={() => setIsCartOpen(false)}
                     className="p-1 hover:bg-white rounded-full transition-colors"
                  >
                     <X className="h-6 w-6 text-gray-500" />
                  </button>
               </div>

               <div className="flex-1 overflow-y-auto p-5 space-y-4">
                  {cart.length === 0 ? (
                     <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                        <ShoppingBag className="h-20 w-20 opacity-20" />
                        <p className="text-lg">Savatingiz bo'sh</p>
                        <button 
                           onClick={() => setIsCartOpen(false)}
                           className="text-primary-600 font-medium hover:underline"
                        >
                           Xarid qilishni boshlash
                        </button>
                     </div>
                  ) : (
                     cart.map((item) => (
                        <div key={item.product.id} className="flex gap-4 items-center bg-white border border-gray-100 p-3 rounded-xl shadow-sm">
                           <img src={item.product.image} alt={item.product.name} className="w-16 h-16 rounded-lg object-cover bg-gray-100" />
                           <div className="flex-1">
                              <h4 className="font-bold text-gray-900 text-sm mb-1">{item.product.name}</h4>
                              <p className="text-primary-600 font-bold text-sm">{item.product.price}</p>
                           </div>
                           <div className="flex flex-col items-end gap-2">
                              <button 
                                 onClick={() => removeFromCart(item.product.id)}
                                 className="text-gray-400 hover:text-red-500 transition-colors"
                              >
                                 <Trash2 className="h-4 w-4" />
                              </button>
                              <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
                                 <button 
                                    onClick={() => updateQuantity(item.product.id, -1)}
                                    className="w-6 h-6 flex items-center justify-center bg-white rounded shadow-sm hover:bg-gray-50 text-gray-600"
                                    disabled={item.quantity <= 1}
                                 >
                                    <Minus className="h-3 w-3" />
                                 </button>
                                 <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                                 <button 
                                    onClick={() => updateQuantity(item.product.id, 1)}
                                    className="w-6 h-6 flex items-center justify-center bg-white rounded shadow-sm hover:bg-gray-50 text-gray-600"
                                 >
                                    <Plus className="h-3 w-3" />
                                 </button>
                              </div>
                           </div>
                        </div>
                     ))
                  )}
               </div>

               {cart.length > 0 && (
                  <div className="p-5 border-t border-gray-100 bg-gray-50 space-y-4">
                     <div>
                        <h3 className="text-sm font-bold text-gray-700 mb-2">To'lov turi</h3>
                        <div className="grid grid-cols-3 gap-2">
                           {['Naqd', 'Click', 'Payme'].map((type) => (
                              <button
                                 key={type}
                                 onClick={() => setPaymentMethod(type as any)}
                                 className={`py-2 px-3 rounded-lg text-sm font-medium border flex items-center justify-center gap-1 transition-all ${
                                    paymentMethod === type 
                                       ? 'bg-primary-600 text-white border-primary-600 shadow-md' 
                                       : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'
                                 }`}
                              >
                                 {type === 'Naqd' ? <Banknote className="h-3 w-3" /> : <CreditCard className="h-3 w-3" />}
                                 {type}
                              </button>
                           ))}
                        </div>
                     </div>

                     <div className="flex justify-between items-center text-lg font-bold text-gray-900 border-t border-gray-200 pt-4">
                        <span>Jami summa:</span>
                        <span>{formatPrice(cartTotalAmount)}</span>
                     </div>

                     <button 
                        onClick={handleCheckout}
                        className="w-full bg-gray-900 text-white py-4 rounded-xl font-bold hover:bg-gray-800 transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
                     >
                        Buyurtma berish
                        <ArrowLeft className="h-4 w-4 rotate-180" />
                     </button>
                  </div>
               )}
            </div>
         </div>
      )}
    </div>
  );
};

export default Marketplace;
