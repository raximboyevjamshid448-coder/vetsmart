import React, { useState } from 'react';
import { AppView, User, Notification } from '../types';
import { 
  Activity, 
  Stethoscope, 
  QrCode, 
  Video, 
  Menu, 
  X, 
  LogOut,
  LayoutGrid,
  ShoppingBag,
  User as UserIcon,
  LogIn,
  Bell,
  Check
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  onLogout: () => void;
  onLoginRequest: () => void;
  user?: User;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: '1', title: 'Emlash vaqti keldi', message: 'Masha (ID: A001) uchun Oqsil kasalligiga qarshi emlash bugun.', time: '10 daqiqa oldin', read: false, type: 'alert' },
  { id: '2', title: 'Buyurtma qabul qilindi', message: 'Buyurtma #ORD-7782 tayyorlanmoqda.', time: '1 soat oldin', read: false, type: 'info' },
  { id: '3', title: 'Dr. Komiljon onlayn', message: 'Siz kutgan veterinar hozir tarmoqda.', time: '2 soat oldin', read: true, type: 'success' },
];

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentView, 
  onChangeView, 
  onLogout, 
  onLoginRequest,
  user 
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const navItems = [
    { view: AppView.DASHBOARD, label: 'Boshqaruv Paneli', icon: LayoutGrid },
    { view: AppView.DIAGNOSIS, label: 'AI Diagnostika', icon: Activity },
    { view: AppView.PASSPORT, label: 'Raqamli Pasport', icon: QrCode },
    { view: AppView.VETS, label: 'Tele-Veterinariya', icon: Video },
    { view: AppView.MARKET, label: 'VetSmart Do\'kon', icon: ShoppingBag },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-primary-700 text-white p-4 flex justify-between items-center sticky top-0 z-50 shadow-md">
        <div className="font-bold text-xl flex items-center gap-2">
          <Stethoscope className="h-6 w-6" />
          VetSmart
        </div>
        <div className="flex items-center gap-4">
           {/* Mobile Notification Bell */}
           <div className="relative">
              <button onClick={() => setShowNotifications(!showNotifications)} className="p-1">
                 <Bell className="h-6 w-6" />
                 {unreadCount > 0 && (
                   <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-primary-700">
                     {unreadCount}
                   </span>
                 )}
              </button>
           </div>
           <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
             {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
           </button>
        </div>
      </div>

      {/* Sidebar Navigation */}
      <div className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out
        md:relative md:translate-x-0
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="h-full flex flex-col">
          {/* Logo Area */}
          <div className="p-6 bg-primary-700 text-white hidden md:flex items-center gap-2">
            <Stethoscope className="h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">VetSmart</h1>
              <p className="text-xs text-primary-100">Super-Ilova</p>
            </div>
          </div>

          {/* User Profile Snippet or Guest Message */}
          {user ? (
            <div 
              onClick={() => {
                onChangeView(AppView.PROFILE);
                setIsMobileMenuOpen(false);
              }}
              className="p-4 bg-primary-50 border-b border-primary-100 flex items-center gap-3 cursor-pointer hover:bg-primary-100 transition-colors"
              title="Mening Kabinetim"
            >
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center border border-primary-200 text-primary-600 overflow-hidden">
                {user.avatar ? (
                  <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="h-6 w-6" />
                )}
              </div>
              <div className="overflow-hidden">
                <h3 className="text-sm font-bold text-gray-900 truncate">{user.name}</h3>
                <p className="text-xs text-primary-600 font-medium flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  {user.role} Premium
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-gray-50 border-b border-gray-100">
               <p className="text-xs text-gray-500 mb-1">Status:</p>
               <div className="flex items-center gap-2 text-gray-700 font-semibold">
                  <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                  Mehmon (Guest)
               </div>
            </div>
          )}

          {/* Navigation Links */}
          <nav className="flex-1 p-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.view}
                onClick={() => {
                  onChangeView(item.view);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  currentView === item.view
                    ? 'bg-primary-50 text-primary-700 font-semibold'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </button>
            ))}
          </nav>

          {/* Auth Actions */}
          <div className="p-4 border-t border-gray-200">
            {user ? (
              <button
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="h-5 w-5" />
                Chiqish
              </button>
            ) : (
              <button
                onClick={onLoginRequest}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gray-900 text-white rounded-xl shadow-lg hover:bg-gray-800 transition-all transform active:scale-95"
              >
                <LogIn className="h-5 w-5" />
                Kirish / Ro'yxatdan o'tish
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Wrapper */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        
        {/* Desktop Header with Notifications */}
        <div className="hidden md:flex justify-between items-center p-4 bg-white border-b border-gray-200">
           <h2 className="text-xl font-bold text-gray-800">
              {currentView === AppView.DASHBOARD && 'Boshqaruv Paneli'}
              {currentView === AppView.DIAGNOSIS && 'AI Diagnostika'}
              {currentView === AppView.PASSPORT && 'Raqamli Pasport'}
              {currentView === AppView.VETS && 'Tele-Veterinariya'}
              {currentView === AppView.MARKET && 'VetSmart Do\'kon'}
              {currentView === AppView.PROFILE && 'Mening Kabinetim'}
           </h2>
           
           <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors relative"
              >
                <Bell className="h-6 w-6 text-gray-600" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                 <div className="absolute right-0 top-12 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 overflow-hidden animate-fadeIn">
                    <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                       <h3 className="font-bold text-gray-800">Bildirishnomalar</h3>
                       {unreadCount > 0 && (
                         <button onClick={markAsRead} className="text-xs text-primary-600 hover:underline">
                           Barchasini o'qildi deb belgilash
                         </button>
                       )}
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                       {notifications.length === 0 ? (
                         <div className="p-8 text-center text-gray-400">
                            Xabarlar yo'q
                         </div>
                       ) : (
                         notifications.map(n => (
                           <div key={n.id} className={`p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors ${!n.read ? 'bg-blue-50/50' : ''}`}>
                              <div className="flex items-start gap-3">
                                 <div className={`mt-1 w-2 h-2 rounded-full flex-shrink-0 ${
                                    n.type === 'alert' ? 'bg-red-500' : n.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                                 }`} />
                                 <div>
                                    <h4 className={`text-sm font-semibold ${!n.read ? 'text-gray-900' : 'text-gray-600'}`}>{n.title}</h4>
                                    <p className="text-xs text-gray-500 mt-1">{n.message}</p>
                                    <p className="text-[10px] text-gray-400 mt-2">{n.time}</p>
                                 </div>
                              </div>
                           </div>
                         ))
                       )}
                    </div>
                 </div>
              )}
           </div>
        </div>

        {/* Mobile Notification Dropdown Overlay */}
        {showNotifications && (
           <div className="md:hidden fixed inset-0 z-40 bg-gray-900/50 backdrop-blur-sm" onClick={() => setShowNotifications(false)}>
              <div className="absolute top-16 right-4 w-80 bg-white rounded-xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
                 <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                    <h3 className="font-bold text-gray-800">Bildirishnomalar</h3>
                    <button onClick={markAsRead} className="text-xs text-primary-600 font-medium">
                      Tozalash
                    </button>
                 </div>
                 <div className="max-h-[60vh] overflow-y-auto">
                    {notifications.map(n => (
                       <div key={n.id} className="p-4 border-b border-gray-50">
                          <h4 className="text-sm font-bold text-gray-800">{n.title}</h4>
                          <p className="text-xs text-gray-600 mt-1">{n.message}</p>
                       </div>
                    ))}
                 </div>
              </div>
           </div>
        )}

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;