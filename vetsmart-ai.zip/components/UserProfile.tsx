import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { ArrowLeft, User as UserIcon, MapPin, Briefcase, Save, CreditCard, Shield, Bell, LogOut, Edit2, Camera } from 'lucide-react';

interface UserProfileProps {
  user: User;
  onGoBack: () => void;
  onUpdateUser: (updatedUser: User) => void;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, onGoBack, onUpdateUser, onLogout }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(user);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    onUpdateUser(formData);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-4">
        <button 
          onClick={onGoBack} 
          className="p-2 rounded-full hover:bg-gray-200 transition-colors bg-white shadow-sm border border-gray-200"
          title="Orqaga"
        >
          <ArrowLeft className="h-5 w-5 text-gray-600" />
        </button>
        <div>
           <h1 className="text-2xl font-bold text-gray-900">Mening Kabinetim</h1>
           <p className="text-gray-500">Shaxsiy ma'lumotlar va sozlamalar</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Profile Card */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-primary-500 to-primary-600"></div>
            
            <div className="relative mt-12 mb-4 group">
              <div className="w-24 h-24 rounded-full bg-white p-1 shadow-lg">
                <div className="w-full h-full rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                  {formData.avatar ? (
                    <img src={formData.avatar} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon className="h-12 w-12 text-gray-400" />
                  )}
                </div>
              </div>
              <button className="absolute bottom-0 right-0 p-2 bg-gray-900 text-white rounded-full hover:bg-gray-700 transition-colors shadow-md">
                <Camera className="h-4 w-4" />
              </button>
            </div>

            <h2 className="text-xl font-bold text-gray-900">{formData.name}</h2>
            <p className="text-primary-600 font-medium mb-4">{formData.role}</p>

            <div className="w-full py-3 px-4 bg-green-50 rounded-xl flex items-center justify-between mb-6">
               <span className="text-sm text-green-700 font-bold flex items-center gap-2">
                 <Shield className="h-4 w-4" />
                 Premium Obuna
               </span>
               <span className="text-xs text-green-600 bg-white px-2 py-1 rounded-md shadow-sm">Active</span>
            </div>

            <button 
              onClick={onLogout}
              className="w-full py-2 flex items-center justify-center gap-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors font-medium"
            >
              <LogOut className="h-4 w-4" />
              Chiqish
            </button>
          </div>

          {/* Quick Stats */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
             <h3 className="font-bold text-gray-900 mb-4">Statistika</h3>
             <div className="space-y-4">
                <div className="flex justify-between items-center">
                   <span className="text-gray-600 text-sm">Hayvonlar soni</span>
                   <span className="font-bold text-gray-900">124</span>
                </div>
                <div className="flex justify-between items-center">
                   <span className="text-gray-600 text-sm">Konsultatsiyalar</span>
                   <span className="font-bold text-gray-900">12</span>
                </div>
                <div className="flex justify-between items-center">
                   <span className="text-gray-600 text-sm">Bu oygi xarajat</span>
                   <span className="font-bold text-gray-900">450k</span>
                </div>
             </div>
          </div>
        </div>

        {/* Right Column: Edit Form */}
        <div className="md:col-span-2">
           <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                 <h3 className="font-bold text-gray-900">Shaxsiy Ma'lumotlar</h3>
                 {!isEditing ? (
                    <button 
                       onClick={() => setIsEditing(true)}
                       className="flex items-center gap-2 text-sm font-medium text-primary-600 hover:text-primary-700 bg-white border border-gray-200 px-3 py-1.5 rounded-lg shadow-sm"
                    >
                       <Edit2 className="h-4 w-4" />
                       Tahrirlash
                    </button>
                 ) : (
                    <button 
                       onClick={handleSave}
                       className="flex items-center gap-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 px-4 py-1.5 rounded-lg shadow-sm transition-all"
                    >
                       <Save className="h-4 w-4" />
                       Saqlash
                    </button>
                 )}
              </div>

              <div className="p-6 space-y-6">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                       <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">To'liq Ism</label>
                       <div className="relative">
                          <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                          <input 
                             type="text" 
                             name="name"
                             value={formData.name}
                             onChange={handleChange}
                             disabled={!isEditing}
                             className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"
                          />
                       </div>
                    </div>
                    <div>
                       <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Telefon</label>
                       <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 flex items-center justify-center text-gray-400 font-bold">📞</span>
                          <input 
                             type="text" 
                             name="phone"
                             value={formData.phone}
                             onChange={handleChange}
                             disabled={!isEditing}
                             className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"
                          />
                       </div>
                    </div>
                    <div className="md:col-span-2">
                       <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Ferma Nomi / Klinika</label>
                       <div className="relative">
                          <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                          <input 
                             type="text" 
                             name="farmName"
                             value={formData.farmName || ''}
                             onChange={handleChange}
                             disabled={!isEditing}
                             placeholder={user.role === 'Fermer' ? "Masalan: 'Baraka Chorva' MChJ" : "Masalan: 'VetMed' klinikasi"}
                             className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"
                          />
                       </div>
                    </div>
                    <div className="md:col-span-2">
                       <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Manzil</label>
                       <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                          <input 
                             type="text" 
                             name="address"
                             value={formData.address || ''}
                             onChange={handleChange}
                             disabled={!isEditing}
                             placeholder="Viloyat, Tuman, Mahalla"
                             className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-500 outline-none disabled:opacity-70 disabled:cursor-not-allowed"
                          />
                       </div>
                    </div>
                 </div>
              </div>
           </div>

           {/* Settings */}
           <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mt-6">
              <div className="p-6 border-b border-gray-100 bg-gray-50">
                 <h3 className="font-bold text-gray-900">Sozlamalar</h3>
              </div>
              <div className="p-6 space-y-4">
                 <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-gray-200">
                    <div className="flex items-center gap-3">
                       <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><Bell className="h-5 w-5" /></div>
                       <div>
                          <h4 className="font-medium text-gray-900">Bildirishnomalar</h4>
                          <p className="text-xs text-gray-500">Telegram va SMS xabarnomalar</p>
                       </div>
                    </div>
                    <div className="w-10 h-6 bg-primary-600 rounded-full relative">
                       <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full"></div>
                    </div>
                 </div>

                 <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-gray-200">
                    <div className="flex items-center gap-3">
                       <div className="bg-purple-100 p-2 rounded-lg text-purple-600"><CreditCard className="h-5 w-5" /></div>
                       <div>
                          <h4 className="font-medium text-gray-900">To'lov Usullari</h4>
                          <p className="text-xs text-gray-500">Karta va hamyonlarni boshqarish</p>
                       </div>
                    </div>
                    <ArrowLeft className="h-5 w-5 text-gray-400 rotate-180" />
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;