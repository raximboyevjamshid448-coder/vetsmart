import React, { useState } from 'react';
import { Star, Video, Phone, Calendar, MapPin, ArrowLeft, Clock, CheckCircle, MessageSquare, Send, X, User } from 'lucide-react';
import { Vet } from '../types';

interface VetConsultationProps {
  onGoBack: () => void;
}

const MOCK_VETS: Vet[] = [
  {
    id: 'v1',
    name: 'Dr. Komiljon Sultonov',
    specialization: 'Yirik shoxli chorva',
    rating: 4.9,
    isOnline: true,
    image: 'https://picsum.photos/seed/doc1/100/100',
    pricePerConsult: '50,000 UZS',
    experience: '15 yil',
    about: 'Yirik chorva mollaridagi yuqumli kasalliklar bo\'yicha oliy toifali mutaxassis.'
  },
  {
    id: 'v2',
    name: 'Dr. Jamshid Raximboyev',
    specialization: 'Uy hayvonlari jarrohi',
    rating: 4.8,
    isOnline: false,
    image: 'https://picsum.photos/seed/doc2/100/100',
    pricePerConsult: '70,000 UZS',
    experience: '8 yil',
    about: 'Murakkab jarrohlik amaliyotlari va travmatologiya bo\'yicha ekspert.'
  },
  {
    id: 'v3',
    name: 'Dr. Aziza Karimova',
    specialization: 'Parrandachilik eksperti',
    rating: 4.7,
    isOnline: true,
    image: 'https://picsum.photos/seed/doc3/100/100',
    pricePerConsult: '45,000 UZS',
    experience: '10 yil',
    about: 'Sanoat parrandachiligi va oziqlantirish rasionlari bo\'yicha maslahatchi.'
  }
];

const VetConsultation: React.FC<VetConsultationProps> = ({ onGoBack }) => {
  const [selectedVet, setSelectedVet] = useState<Vet | null>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  
  // Booking Form State
  const [bookDate, setBookDate] = useState('');
  const [bookTime, setBookTime] = useState('');

  // Chat State
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<{sender: 'user' | 'vet', text: string}[]>([
    { sender: 'vet', text: 'Assalomu alaykum! Sizga qanday yordam bera olaman?' }
  ]);

  const openBooking = (vet: Vet) => {
    setSelectedVet(vet);
    setIsBookingOpen(true);
  };

  const openChat = (vet: Vet) => {
    setSelectedVet(vet);
    setIsChatOpen(true);
  };

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setIsBookingOpen(false);
      setSelectedVet(null);
      setBookDate('');
      setBookTime('');
    }, 2500);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!chatMessage.trim()) return;
    
    setChatHistory(prev => [...prev, { sender: 'user', text: chatMessage }]);
    const currentMsg = chatMessage;
    setChatMessage('');
    
    // Simulate vet reply
    setTimeout(() => {
       setChatHistory(prev => [...prev, { sender: 'vet', text: `Rahmat. "${currentMsg}" bo'yicha ma'lumotni ko'rib chiqib, tez orada javob beraman.` }]);
    }, 1500);
  };

  return (
    <div className="space-y-6 relative h-full">
      <div className="flex items-center gap-4 mb-4">
        <button 
          onClick={onGoBack} 
          className="p-2 rounded-full hover:bg-gray-200 transition-colors bg-white shadow-sm border border-gray-200"
          title="Orqaga"
        >
          <ArrowLeft className="h-5 w-5 text-gray-600" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Telehealth Veterinarlar</h1>
          <p className="text-gray-500">Malakali mutaxassislar bilan onlayn aloqa</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-primary-600 to-primary-800 rounded-2xl p-8 text-white mb-8 shadow-lg">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h2 className="text-3xl font-bold mb-2">Onlayn Konsultatsiya</h2>
            <p className="opacity-90 max-w-xl text-lg">
              Videokonsultatsiya yoki chat orqali masofadan turib yordam oling. 
              Vaqtni tejang va hayvoningiz salomatligini asrang.
            </p>
          </div>
          <div className="bg-white/20 p-4 rounded-full backdrop-blur-md">
            <Video className="h-10 w-10 text-white" />
          </div>
        </div>
      </div>

      {/* Vet List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-20">
        {MOCK_VETS.map((vet) => (
          <div key={vet.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-xl transition-all group flex flex-col h-full">
            <div className="flex items-start gap-4">
              <div className="relative">
                <img 
                  src={vet.image} 
                  alt={vet.name} 
                  className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-sm group-hover:scale-105 transition-transform"
                />
                {vet.isOnline && (
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full animate-pulse" title="Onlayn"></div>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-900 line-clamp-1">{vet.name}</h3>
                <p className="text-sm text-primary-600 font-medium">{vet.specialization}</p>
                <div className="flex items-center gap-1 mt-1 text-yellow-500">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="text-sm font-bold text-gray-700">{vet.rating}</span>
                </div>
              </div>
            </div>

            <p className="mt-4 text-sm text-gray-500 line-clamp-2 min-h-[40px]">
              {vet.about}
            </p>

            <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center text-sm text-gray-500">
               <div className="flex items-center gap-1">
                 <Clock className="h-4 w-4" />
                 <span>{vet.experience} tajriba</span>
               </div>
               <div className="font-bold text-gray-900">{vet.pricePerConsult}</div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-6">
              <button 
                onClick={() => openChat(vet)}
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-blue-50 text-blue-600 font-semibold hover:bg-blue-100 transition-colors"
              >
                <MessageSquare className="h-4 w-4" />
                Chat
              </button>
              <button 
                onClick={() => openBooking(vet)}
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-primary-600 text-white font-semibold hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/20"
              >
                <Calendar className="h-4 w-4" />
                Yozilish
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Booking Modal */}
      {isBookingOpen && selectedVet && (
        <div className="fixed inset-0 bg-gray-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fadeIn">
           <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
              <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                 <h3 className="font-bold text-gray-900">Qabulga yozilish</h3>
                 <button onClick={() => setIsBookingOpen(false)} className="p-1 hover:bg-gray-200 rounded-full"><X className="h-5 w-5 text-gray-500" /></button>
              </div>
              
              {!bookingSuccess ? (
                <form onSubmit={handleBook} className="p-6 space-y-4">
                   <div className="flex items-center gap-3 mb-4 bg-blue-50 p-3 rounded-xl border border-blue-100">
                      <img src={selectedVet.image} alt={selectedVet.name} className="w-12 h-12 rounded-full object-cover" />
                      <div>
                         <p className="font-bold text-gray-900">{selectedVet.name}</p>
                         <p className="text-xs text-blue-600 font-medium">{selectedVet.specialization}</p>
                      </div>
                   </div>

                   <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Sana</label>
                      <input 
                        type="date" 
                        required
                        value={bookDate}
                        onChange={(e) => setBookDate(e.target.value)}
                        className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none" 
                      />
                   </div>
                   <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Vaqt</label>
                      <input 
                        type="time" 
                        required
                        value={bookTime}
                        onChange={(e) => setBookTime(e.target.value)}
                        className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none" 
                      />
                   </div>

                   <button type="submit" className="w-full bg-primary-600 text-white py-3 rounded-xl font-bold hover:bg-primary-700 transition-colors mt-4">
                      Tasdiqlash ({selectedVet.pricePerConsult})
                   </button>
                </form>
              ) : (
                <div className="p-8 flex flex-col items-center text-center animate-scaleIn">
                   <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                   </div>
                   <h3 className="text-xl font-bold text-gray-900 mb-2">Muvaffaqiyatli!</h3>
                   <p className="text-gray-500 mb-4">
                      Sizning arizangiz qabul qilindi. {selectedVet.name} tez orada tasdiqlaydi.
                   </p>
                   <div className="bg-gray-50 p-3 rounded-lg w-full text-sm text-gray-600 border border-gray-100">
                      <p>Sana: <span className="font-bold">{bookDate}</span></p>
                      <p>Vaqt: <span className="font-bold">{bookTime}</span></p>
                   </div>
                </div>
              )}
           </div>
        </div>
      )}

      {/* Chat Modal */}
      {isChatOpen && selectedVet && (
        <div className="fixed inset-0 bg-gray-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fadeIn">
           <div className="bg-white rounded-2xl w-full max-w-lg h-[80vh] shadow-2xl overflow-hidden flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-primary-700 text-white">
                 <div className="flex items-center gap-3">
                    <div className="relative">
                       <img src={selectedVet.image} alt={selectedVet.name} className="w-10 h-10 rounded-full border-2 border-white/50" />
                       <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-400 border border-white rounded-full"></div>
                    </div>
                    <div>
                       <h3 className="font-bold text-sm md:text-base">{selectedVet.name}</h3>
                       <p className="text-xs text-primary-200">{selectedVet.specialization}</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-white/10 rounded-full"><Phone className="h-5 w-5" /></button>
                    <button className="p-2 hover:bg-white/10 rounded-full"><Video className="h-5 w-5" /></button>
                    <button onClick={() => setIsChatOpen(false)} className="p-2 hover:bg-white/10 rounded-full"><X className="h-5 w-5" /></button>
                 </div>
              </div>

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                 {chatHistory.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                       <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                          msg.sender === 'user' 
                             ? 'bg-primary-600 text-white rounded-tr-none' 
                             : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none shadow-sm'
                       }`}>
                          {msg.text}
                       </div>
                    </div>
                 ))}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-gray-100 flex gap-2">
                 <input 
                    type="text" 
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    placeholder="Xabar yozing..."
                    className="flex-1 p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                 />
                 <button 
                    type="submit" 
                    disabled={!chatMessage.trim()}
                    className="p-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700 disabled:bg-gray-300 transition-colors"
                 >
                    <Send className="h-5 w-5" />
                 </button>
              </form>
           </div>
        </div>
      )}

    </div>
  );
};

export default VetConsultation;