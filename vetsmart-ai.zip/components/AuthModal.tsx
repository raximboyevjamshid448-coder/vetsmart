import React, { useState } from 'react';
import { X, CheckCircle, CreditCard, User, Phone, LogIn, Award } from 'lucide-react';
import { UserRole } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (name: string, phone: string, role: UserRole) => void;
  initialRole?: UserRole;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin, initialRole = 'Fermer' }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>(initialRole);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && phone) {
      setStep(2);
    }
  };

  const handlePayment = () => {
    setIsLoading(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsLoading(false);
      onLogin(name, phone, role);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-gray-900/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm transition-all">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-fadeIn relative flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
           <h3 className="font-bold text-gray-900 flex items-center gap-2">
             <LogIn className="h-5 w-5 text-primary-600" />
             Tizimga kirish
           </h3>
           <button 
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Progress Bar (Subtle) */}
        <div className="h-1 w-full bg-gray-100">
          <div 
            className="h-full bg-primary-500 transition-all duration-300" 
            style={{ width: step === 1 ? '50%' : '100%' }}
          />
        </div>

        <div className="p-6 overflow-y-auto">
          {step === 1 ? (
            <form onSubmit={handleNext} className="space-y-5">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center mx-auto mb-3">
                   <User className="h-8 w-8" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">Xush kelibsiz!</h2>
                <p className="text-sm text-gray-500">Iltimos, o'zingiz haqingizda ma'lumot bering</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Siz kimsiz?</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setRole('Fermer')}
                    className={`p-3 rounded-xl border-2 text-center transition-all flex flex-col items-center gap-1 ${
                      role === 'Fermer' 
                        ? 'border-primary-500 bg-primary-50 text-primary-700 font-bold shadow-sm' 
                        : 'border-gray-100 text-gray-600 hover:border-gray-200'
                    }`}
                  >
                    <span className="text-2xl">👨‍🌾</span>
                    Fermer
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('Veterinar')}
                    className={`p-3 rounded-xl border-2 text-center transition-all flex flex-col items-center gap-1 ${
                      role === 'Veterinar' 
                        ? 'border-primary-500 bg-primary-50 text-primary-700 font-bold shadow-sm' 
                        : 'border-gray-100 text-gray-600 hover:border-gray-200'
                    }`}
                  >
                    <span className="text-2xl">👨‍⚕️</span>
                    Veterinar
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">To'liq Ism</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      required
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ism Familiya"
                      className="w-full pl-10 pr-4 py-3 border border-gray-200 bg-gray-50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:bg-white focus:border-transparent outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                   <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Telefon Raqam</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input
                      required
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+998 90 123 45 67"
                      className="w-full pl-10 pr-4 py-3 border border-gray-200 bg-gray-50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:bg-white focus:border-transparent outline-none transition-all"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gray-900 text-white py-4 rounded-xl font-bold hover:bg-gray-800 transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
              >
                Davom etish
              </button>
            </form>
          ) : (
            <div className="animate-fadeIn">
              <div className="text-center mb-6">
                 <div className="w-16 h-16 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-3">
                   <Award className="h-8 w-8" />
                 </div>
                 <h2 className="text-xl font-bold text-gray-900">Premium Obuna</h2>
                 <p className="text-sm text-gray-500">To'liq imkoniyatlardan foydalanish uchun</p>
              </div>

              <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white p-6 rounded-2xl shadow-xl mb-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-white opacity-5 rounded-full -mr-10 -mt-10"></div>
                <div className="absolute bottom-0 left-0 w-16 h-16 bg-white opacity-5 rounded-full -ml-8 -mb-8"></div>
                
                <div className="flex justify-between items-start mb-4">
                   <div>
                      <h3 className="text-lg font-bold">{role} Premium</h3>
                      <p className="text-xs text-gray-400">Oylik obuna</p>
                   </div>
                   <span className="bg-primary-500 text-white text-xs px-2 py-1 rounded font-bold">PRO</span>
                </div>
                
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-3xl font-bold text-white">
                    {role === 'Fermer' ? '50,000' : '70,000'}
                  </span>
                  <span className="text-gray-400 text-sm">UZS</span>
                </div>
                
                <div className="space-y-2 text-sm text-gray-300">
                   <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary-500" />
                      <span>Cheksiz AI Diagnostika</span>
                   </div>
                   <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary-500" />
                      <span>{role === 'Fermer' ? 'Veterinar bilan video aloqa' : 'Bemorlar bazasi'}</span>
                   </div>
                </div>
              </div>

              <div className="border border-gray-200 rounded-xl p-3 mb-6 cursor-pointer hover:border-primary-500 transition-colors flex items-center gap-3 bg-white group">
                 <div className="bg-blue-50 p-2 rounded-lg group-hover:bg-blue-100 transition-colors">
                    <CreditCard className="h-6 w-6 text-blue-600" />
                 </div>
                 <div className="flex-1">
                    <p className="font-bold text-gray-900 text-sm">Click / Payme</p>
                    <p className="text-xs text-gray-500">Karta orqali xavfsiz to'lov</p>
                 </div>
                 <div className="h-5 w-5 rounded-full border-2 border-primary-500 flex items-center justify-center">
                    <div className="h-2.5 w-2.5 rounded-full bg-primary-500" />
                 </div>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  onClick={handlePayment}
                  disabled={isLoading}
                  className="w-full bg-primary-600 text-white py-3.5 rounded-xl font-bold hover:bg-primary-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-primary-500/30 active:scale-95"
                >
                  {isLoading ? (
                    <>Tasdiqlanmoqda...</>
                  ) : (
                    <>
                      Obuna bo'lish va Kirish
                    </>
                  )}
                </button>
                
                <button 
                  onClick={() => setStep(1)}
                  className="text-sm text-gray-500 hover:text-gray-900 font-medium py-2"
                >
                  Ortga qaytish
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthModal;