import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, AlertTriangle, FileText, Camera, X, Image as ImageIcon, ArrowLeft, Save, History, ChevronRight } from 'lucide-react';
import { getVeterinaryAdvice } from '../services/geminiService';
import { ChatMessage, AnimalType, MedicalRecord } from '../types';

interface AIDiagnosisProps {
  onGoBack: () => void;
}

const AIDiagnosis: React.FC<AIDiagnosisProps> = ({ onGoBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: "Assalomu alaykum! Men VetSmart sun'iy intellekt yordamchisiman. \n\nMen nafaqat matn, balki **rasmlarni ham tahlil qila olaman**. \nHayvoningizdagi belgilarni yozing yoki kasallik joyini rasmga olib yuboring.",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedAnimal, setSelectedAnimal] = useState<string>(AnimalType.CATTLE);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  // History State
  const [showHistory, setShowHistory] = useState(false);
  const [savedDiagnoses, setSavedDiagnoses] = useState<MedicalRecord[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;

    const currentImage = selectedImage;
    const currentInput = input;

    const userMessage: ChatMessage = {
      role: 'user',
      text: currentInput,
      image: currentImage || undefined,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSelectedImage(null); 
    if (fileInputRef.current) fileInputRef.current.value = '';
    
    setIsLoading(true);

    const aiResponseText = await getVeterinaryAdvice(currentInput, selectedAnimal, currentImage || undefined);

    const aiMessage: ChatMessage = {
      role: 'model',
      text: aiResponseText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, aiMessage]);
    setIsLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSaveDiagnosis = (messageText: string) => {
    // Extract simple title from first line or generate one
    const title = messageText.split('\n')[0].replace(/\*\*/g, '').substring(0, 30) + '...';
    
    const newRecord: MedicalRecord = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString(),
      diagnosis: title,
      treatment: "AI Tavsiyasi",
      vetName: "VetSmart AI",
      fullAdvice: messageText,
      animalType: selectedAnimal
    };

    setSavedDiagnoses(prev => [newRecord, ...prev]);
    setShowHistory(true);
  };

  return (
    <div className="h-full flex relative bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      
      {/* Main Chat Content */}
      <div className="flex-1 flex flex-col h-full relative z-0">
        {/* Header */}
        <div className="p-4 border-b border-gray-100 bg-primary-50 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={onGoBack} 
              className="p-2 -ml-2 rounded-full hover:bg-white/50 transition-colors text-gray-600"
              title="Orqaga"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="bg-primary-100 p-2 rounded-lg">
              <Bot className="h-6 w-6 text-primary-600" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900">AI Diagnostika</h2>
              <p className="text-xs text-gray-500">Vizual va matnli tahlil</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
             <select 
              value={selectedAnimal}
              onChange={(e) => setSelectedAnimal(e.target.value)}
              className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block p-2.5"
            >
              {Object.values(AnimalType).map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className={`p-2.5 rounded-lg border transition-colors relative ${
                showHistory ? 'bg-primary-100 text-primary-700 border-primary-200' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
              }`}
              title="Tarix"
            >
               <History className="h-5 w-5" />
               {savedDiagnoses.length > 0 && (
                 <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border border-white"></span>
               )}
            </button>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex flex-col max-w-[90%] md:max-w-[75%] gap-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                
                <div className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    msg.role === 'user' ? 'bg-secondary-500' : 'bg-primary-600'
                  }`}>
                    {msg.role === 'user' ? <User className="h-5 w-5 text-white" /> : <Bot className="h-5 w-5 text-white" />}
                  </div>
                  
                  <div className={`p-4 rounded-2xl shadow-sm text-sm whitespace-pre-wrap ${
                    msg.role === 'user' 
                      ? 'bg-secondary-500 text-white rounded-tr-none' 
                      : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
                  }`}>
                    {msg.image && (
                      <div className="mb-3 rounded-lg overflow-hidden border border-white/20">
                        <img src={msg.image} alt="User upload" className="max-w-full max-h-64 object-cover" />
                      </div>
                    )}
                     {msg.text}

                     {/* Save Button for AI responses */}
                     {msg.role === 'model' && idx !== 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-100 flex justify-end">
                           <button 
                            onClick={() => handleSaveDiagnosis(msg.text)}
                            className="flex items-center gap-1 text-xs font-bold text-primary-600 hover:bg-primary-50 px-2 py-1 rounded transition-colors"
                           >
                              <Save className="h-3 w-3" />
                              Natijani saqlash
                           </button>
                        </div>
                     )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start w-full">
               <div className="flex gap-2 max-w-[70%]">
                 <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center">
                   <Bot className="h-5 w-5 text-white" />
                 </div>
                 <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-gray-100 flex items-center gap-2">
                   <Loader2 className="h-4 w-4 animate-spin text-primary-500" />
                   <span className="text-sm text-gray-500">
                      {selectedImage ? "Rasm tahlil qilinmoqda..." : "Tahlil qilinmoqda..."}
                   </span>
                 </div>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-gray-100">
           {/* Warning Banner */}
           <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-2 px-3 mb-3 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <p className="text-xs text-yellow-700">
                <span className="font-bold">Eslatma:</span> AI tashxisi professional veterinar maslahatini o'rnini bosmaydi.
              </p>
           </div>

          {selectedImage && (
            <div className="mb-2 relative inline-block group">
               <img src={selectedImage} alt="Preview" className="h-20 w-20 object-cover rounded-lg border border-gray-300" />
               <div className="absolute inset-0 bg-black/20 rounded-lg group-hover:flex hidden items-center justify-center">
                  <button onClick={clearImage} className="bg-red-500 text-white rounded-full p-1 shadow-md hover:bg-red-600">
                    <X className="h-4 w-4" />
                  </button>
               </div>
            </div>
          )}

          <div className="flex gap-2 items-end">
            <div className="flex-1 relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Simptomlarni yozing yoki rasm yuklang..."
                className="w-full p-3 pr-10 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all"
                disabled={isLoading}
              />
            </div>

            <input 
              type="file" 
              accept="image/*" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              className="hidden" 
            />
            
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="bg-gray-100 hover:bg-gray-200 text-gray-600 p-3 rounded-xl transition-colors"
              title="Rasm yuklash"
            >
               <Camera className="h-5 w-5" />
            </button>

            <button
              onClick={handleSend}
              disabled={isLoading || (!input.trim() && !selectedImage)}
              className="bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-3 rounded-xl transition-colors flex items-center justify-center"
            >
              {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* History Drawer */}
      <div className={`absolute top-0 right-0 h-full w-80 bg-white shadow-2xl border-l border-gray-200 transform transition-transform duration-300 z-10 flex flex-col ${showHistory ? 'translate-x-0' : 'translate-x-full'}`}>
         <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
               <History className="h-5 w-5 text-gray-500" />
               Tarix
            </h3>
            <button onClick={() => setShowHistory(false)} className="p-1 hover:bg-gray-200 rounded-full">
               <X className="h-5 w-5 text-gray-500" />
            </button>
         </div>
         <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {savedDiagnoses.length === 0 ? (
               <div className="text-center text-gray-400 mt-10">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-20" />
                  <p>Saqlangan tashxislar yo'q</p>
               </div>
            ) : (
               savedDiagnoses.map((record) => (
                  <div key={record.id} className="bg-white border border-gray-100 p-3 rounded-xl shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
                     <div className="flex justify-between items-start mb-1">
                        <span className="text-xs text-primary-600 font-bold bg-primary-50 px-2 py-0.5 rounded">{record.animalType}</span>
                        <span className="text-xs text-gray-400">{record.date}</span>
                     </div>
                     <h4 className="font-bold text-gray-800 text-sm mb-1 line-clamp-2">{record.diagnosis}</h4>
                     <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-gray-500">AI VetSmart</span>
                        <ChevronRight className="h-4 w-4 text-gray-300 group-hover:text-primary-500" />
                     </div>
                  </div>
               ))
            )}
         </div>
      </div>
    </div>
  );
};

export default AIDiagnosis;