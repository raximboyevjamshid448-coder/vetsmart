import React from 'react';
import { ArrowRight, CheckCircle, ShieldCheck, Cpu, Heart, Check, PlayCircle } from 'lucide-react';
import { UserRole } from '../types';

interface LandingPageProps {
  onGetStarted: () => void;
  onSubscribe: (role: UserRole) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onSubscribe }) => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative bg-primary-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/1920/1080?grayscale')] opacity-10 bg-cover bg-center" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <div className="md:w-2/3">
            <div className="inline-flex items-center gap-2 bg-primary-800 rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-primary-200 mb-6">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
              VetSmart AI 2.0
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Hayvonlaringiz sog'lig'i <br />
              <span className="text-primary-400">Sun'iy Intellekt</span> himoyasida
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl">
              VetSmart — fermerlar va uy hayvonlari egalari uchun yagona ekotizim. 
              Kasalliklarni erta aniqlang, veterinarlar bilan onlayn bog'laning va 
              hayvonlaringiz tarixini raqamli pasportda saqlang.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onGetStarted}
                className="bg-primary-500 hover:bg-primary-600 text-white font-bold py-4 px-8 rounded-full flex items-center justify-center gap-2 transition-all transform hover:scale-105 shadow-lg shadow-primary-500/30"
              >
                Ilovaga o'tish
                <ArrowRight className="h-5 w-5" />
              </button>
              <button
                 onClick={() => {
                     const element = document.getElementById('pricing');
                     element?.scrollIntoView({ behavior: 'smooth' });
                 }}
                 className="bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 text-white font-bold py-4 px-8 rounded-full transition-all flex items-center justify-center gap-2"
              >
                <PlayCircle className="h-5 w-5" />
                Tariflarni ko'rish
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Features Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Nega aynan VetSmart?</h2>
            <p className="mt-4 text-gray-600">Biz chorvachilikdagi eng dolzarb muammolarga yechim beramiz</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                <Cpu className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">AI Diagnostika</h3>
              <p className="text-gray-600">
                Hayvondagi simptomlarni kiriting va Gemini AI orqali 3 soniyada dastlabki tashxis va tavsiyalar oling.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center text-green-600 mb-6">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Raqamli Pasport & NFC</h3>
              <p className="text-gray-600">
                Qog'ozbozlik yo'q. Har bir hayvonning emlash va kasallik tarixini NFC teg orqali bir teginishda ko'ring.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center text-purple-600 mb-6">
                <Heart className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Telehealth Veterinariya</h3>
              <p className="text-gray-600">
                Malakali veterinarlar bilan istalgan vaqtda video qo'ng'iroq qiling. Qishloq hududlari uchun ayni muddao.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section (Obuna) */}
      <section id="pricing" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Qulay Obuna Tariflari</h2>
            <p className="mt-4 text-gray-600">Mehmon rejimida bepul. Qo'shimcha imkoniyatlar uchun obuna bo'ling.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
             {/* Fermer Plan */}
             <div className="bg-white rounded-3xl p-8 border border-gray-200 shadow-xl hover:border-primary-500 transition-colors relative overflow-hidden group">
                <div className="absolute top-0 right-0 bg-gray-100 text-gray-600 px-4 py-2 rounded-bl-2xl font-bold text-sm group-hover:bg-primary-500 group-hover:text-white transition-colors">
                   Fermerlar uchun
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Fermer Basic</h3>
                <div className="flex items-baseline gap-1 mb-6">
                   <span className="text-4xl font-bold text-primary-600">50,000</span>
                   <span className="text-gray-500 font-medium">UZS / oy</span>
                </div>
                
                <ul className="space-y-4 mb-8">
                   <li className="flex items-center gap-3">
                      <div className="bg-green-100 rounded-full p-1"><Check className="h-4 w-4 text-green-600" /></div>
                      <span className="text-gray-600">AI Diagnostika (Cheksiz)</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-green-100 rounded-full p-1"><Check className="h-4 w-4 text-green-600" /></div>
                      <span className="text-gray-600">Raqamli Pasport (100 tagacha)</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-green-100 rounded-full p-1"><Check className="h-4 w-4 text-green-600" /></div>
                      <span className="text-gray-600">Veterinar bilan videosuhbat</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-green-100 rounded-full p-1"><Check className="h-4 w-4 text-green-600" /></div>
                      <span className="text-gray-600">NFC Teglar do'koniga kirish</span>
                   </li>
                </ul>

                <button 
                  onClick={() => onSubscribe('Fermer')}
                  className="w-full py-4 rounded-xl bg-gray-900 text-white font-bold hover:bg-gray-800 transition-all"
                >
                   Obuna bo'lish
                </button>
             </div>

             {/* Veterinar Plan */}
             <div className="bg-white rounded-3xl p-8 border border-gray-200 shadow-xl hover:border-blue-500 transition-colors relative overflow-hidden group">
                <div className="absolute top-0 right-0 bg-blue-100 text-blue-600 px-4 py-2 rounded-bl-2xl font-bold text-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
                   Mutaxassislar uchun
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Vet Pro</h3>
                <div className="flex items-baseline gap-1 mb-6">
                   <span className="text-4xl font-bold text-blue-600">70,000</span>
                   <span className="text-gray-500 font-medium">UZS / oy</span>
                </div>
                
                <ul className="space-y-4 mb-8">
                   <li className="flex items-center gap-3">
                      <div className="bg-blue-100 rounded-full p-1"><Check className="h-4 w-4 text-blue-600" /></div>
                      <span className="text-gray-600">Bemorlar bazasini boshqarish</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-blue-100 rounded-full p-1"><Check className="h-4 w-4 text-blue-600" /></div>
                      <span className="text-gray-600">Online Konsultatsiyalar o'tkazish</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-blue-100 rounded-full p-1"><Check className="h-4 w-4 text-blue-600" /></div>
                      <span className="text-gray-600">Professional Tashxis vositalari</span>
                   </li>
                   <li className="flex items-center gap-3">
                      <div className="bg-blue-100 rounded-full p-1"><Check className="h-4 w-4 text-blue-600" /></div>
                      <span className="text-gray-600">Reyting tizimida qatnashish</span>
                   </li>
                </ul>

                <button 
                  onClick={() => onSubscribe('Veterinar')}
                  className="w-full py-4 rounded-xl bg-primary-600 text-white font-bold hover:bg-primary-700 transition-all"
                >
                   Obuna bo'lish
                </button>
             </div>
          </div>
        </div>
      </section>

      {/* Stats / Trust */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <img 
              src="https://picsum.photos/seed/vet/800/600" 
              alt="Veterinarian with tablet" 
              className="rounded-2xl shadow-2xl"
            />
          </div>
          <div className="flex-1 space-y-6">
            <h2 className="text-3xl font-bold text-gray-900">Fermerlar va Veterinarlar Ishonchi</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary-500 mt-1" />
                <div>
                  <h4 className="font-bold">Kasallikni erta aniqlash</h4>
                  <p className="text-gray-600 text-sm">Iqtisodiy zararni 40% gacha kamaytiradi.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary-500 mt-1" />
                <div>
                  <h4 className="font-bold">Markazlashgan Baza</h4>
                  <p className="text-gray-600 text-sm">Barcha ma'lumotlar bulutda xavfsiz saqlanadi.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary-500 mt-1" />
                <div>
                  <h4 className="font-bold">Ochiq Manbali Platforma</h4>
                  <p className="text-gray-600 text-sm">Doimiy rivojlanish va integratsiya imkoniyati.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4 text-white font-bold text-2xl">
            <ShieldCheck className="h-8 w-8 text-primary-500" />
            VetSmart
          </div>
          <p className="mb-8">Chorvachilikni raqamlashtirish orqali kelajakni quramiz.</p>
          <div className="text-sm">
            Mualliflar: <span className="text-white">Sultonov Komronbek</span> & <span className="text-white">Raximboyev Jamshidbek</span>
          </div>
          <div className="mt-8 text-xs text-gray-600">
            &copy; 2024 VetSmart Project. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;