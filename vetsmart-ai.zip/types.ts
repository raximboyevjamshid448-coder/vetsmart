export enum AnimalType {
  CATTLE = 'Qoramol',
  SHEEP = 'Qo\'y',
  HORSE = 'Ot',
  DOG = 'It',
  CAT = 'Mushuk',
  POULTRY = 'Parranda'
}

export type UserRole = 'Fermer' | 'Veterinar';

export interface User {
  name: string;
  phone: string;
  role: UserRole;
  subscriptionActive: boolean;
  farmName?: string;
  address?: string;
  avatar?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'alert' | 'info' | 'success';
}

export interface Vaccine {
  name: string;
  date: string;
  nextDueDate: string;
}

export interface MedicalRecord {
  id?: string;
  date: string;
  diagnosis: string;
  treatment: string;
  vetName: string; // Or "AI VetSmart"
  fullAdvice?: string; 
  symptoms?: string;
  animalType?: string;
}

export interface Animal {
  id: string;
  nfcId: string;
  name: string;
  type: AnimalType;
  breed: string;
  age: string;
  weight: string;
  image: string;
  owner: string;
  vaccines: Vaccine[];
  history: MedicalRecord[];
  status: 'Sog\'lom' | 'Kasal' | 'Davolanmoqda';
}

export interface Vet {
  id: string;
  name: string;
  specialization: string;
  rating: number;
  isOnline: boolean;
  image: string;
  pricePerConsult: string;
  experience?: string;
  about?: string;
}

export interface Booking {
  id: string;
  vetId: string;
  vetName: string;
  date: string;
  time: string;
  status: 'confirmed' | 'pending';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  image?: string;
}

export interface Product {
  id: string;
  name: string;
  price: string;
  category: 'Device' | 'Medicine' | 'Feed';
  image: string;
  description: string;
}

export enum AppView {
  LANDING = 'LANDING',
  DASHBOARD = 'DASHBOARD',
  DIAGNOSIS = 'DIAGNOSIS',
  PASSPORT = 'PASSPORT',
  VETS = 'VETS',
  MARKET = 'MARKET',
  LOGIN = 'LOGIN',
  PROFILE = 'PROFILE'
}