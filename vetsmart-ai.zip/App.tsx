import React, { useState } from 'react';
import Layout from './components/Layout';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import AIDiagnosis from './components/AIDiagnosis';
import AnimalPassport from './components/AnimalPassport';
import VetConsultation from './components/VetConsultation';
import Marketplace from './components/Marketplace';
import UserProfile from './components/UserProfile';
import AuthModal from './components/AuthModal';
import { AppView, User, UserRole } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [user, setUser] = useState<User | undefined>(undefined);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [selectedRoleForAuth, setSelectedRoleForAuth] = useState<UserRole>('Fermer');

  // Navigate to Dashboard as Guest
  const handleGetStarted = () => {
    setCurrentView(AppView.DASHBOARD);
  };

  // Handle Back Button Logic
  const handleGoBack = () => {
    if (currentView === AppView.DASHBOARD) {
      setCurrentView(AppView.LANDING);
    } else {
      setCurrentView(AppView.DASHBOARD);
    }
  };

  // Open Auth Modal explicitly (triggered from Layout or Landing)
  const handleOpenAuth = (role: UserRole = 'Fermer') => {
    setSelectedRoleForAuth(role);
    setIsAuthModalOpen(true);
  };

  // Complete Login/Registration/Subscription
  const handleAuthComplete = (name: string, phone: string, role: UserRole) => {
    setUser({
      name,
      phone,
      role,
      subscriptionActive: true,
      farmName: role === 'Fermer' ? 'Mening Fermam' : undefined,
      address: 'O\'zbekiston, Toshkent'
    });
    setIsAuthModalOpen(false);
    // If we were on landing, go to dashboard. Otherwise stay on current view.
    if (currentView === AppView.LANDING) {
      setCurrentView(AppView.DASHBOARD);
    }
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
  };

  const handleLogout = () => {
    setUser(undefined);
    setCurrentView(AppView.LANDING);
  };

  const renderContent = () => {
    switch (currentView) {
      case AppView.LANDING:
        return (
          <LandingPage 
            onGetStarted={handleGetStarted} 
            onSubscribe={(role) => handleOpenAuth(role)}
          />
        );
      case AppView.DASHBOARD:
        return <Dashboard onGoBack={handleGoBack} onChangeView={setCurrentView} />;
      case AppView.DIAGNOSIS:
        return <AIDiagnosis onGoBack={handleGoBack} />;
      case AppView.PASSPORT:
        return <AnimalPassport onGoBack={handleGoBack} />;
      case AppView.VETS:
        return <VetConsultation onGoBack={handleGoBack} />;
      case AppView.MARKET:
        return <Marketplace onGoBack={handleGoBack} />;
      case AppView.PROFILE:
        return user ? (
          <UserProfile 
            user={user} 
            onGoBack={handleGoBack} 
            onUpdateUser={handleUpdateUser}
            onLogout={handleLogout}
          /> 
        ) : (
          <Dashboard onGoBack={handleGoBack} onChangeView={setCurrentView} />
        );
      default:
        return <Dashboard onGoBack={handleGoBack} onChangeView={setCurrentView} />;
    }
  };

  return (
    <>
      {currentView === AppView.LANDING ? (
        renderContent()
      ) : (
        <Layout 
          currentView={currentView} 
          onChangeView={setCurrentView}
          onLogout={handleLogout}
          onLoginRequest={() => handleOpenAuth('Fermer')}
          user={user}
        >
          {renderContent()}
        </Layout>
      )}

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onLogin={handleAuthComplete}
        initialRole={selectedRoleForAuth}
      />
    </>
  );
};

export default App;