import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

export const getVeterinaryAdvice = async (symptoms: string, animalType: string, base64Image?: string): Promise<string> => {
  try {
    if (!apiKey) {
      return "DIQQAT: API kaliti topilmadi. Iltimos, tizim sozlamalarini tekshiring.";
    }

    const systemInstruction = "You are a helpful veterinary AI assistant named 'VetSmart'. You analyze symptoms and images of animals to provide preliminary advice. Always include a disclaimer that you are an AI and not a replacement for a physical veterinary exam. Respond in Uzbek language.";

    const textPrompt = `
      Foydalanuvchi quyidagi hayvon haqida ma'lumot kiritdi:
      Hayvon turi: ${animalType}
      Simptomlar/Izoh: ${symptoms}

      ${base64Image ? "Foydalanuvchi hayvonning rasmini ham yukladi. Rasmni diqqat bilan tahlil qiling (jarohatlar, teri holati, ko'zlar, va h.k.)." : ""}

      Iltimos, quyidagi tuzilishda javob ber:
      1. **Tahlil**: ${base64Image ? "Rasm va matnga asoslangan xulosa." : "Simptomlarga asoslangan xulosa."}
      2. **Taxminiy Tashxis**: 2-3 ta ehtimoliy sabab.
      3. **Xavflilik Darajasi**: Past, O'rta yoki Yuqori.
      4. **Tavsiyalar**: Uy sharoitida birinchi yordam.
      5. **Ogohlantirish**: Veterinar ko'rigi zarurligi haqida.
      
      Javobni o'zbek tilida, professional lekin tushunarli tilda yoz.
    `;

    const parts: any[] = [{ text: textPrompt }];

    // If an image is provided, add it to the request parts
    if (base64Image) {
      // Remove data:image/png;base64, prefix if present for the API call
      const cleanBase64 = base64Image.split(',')[1];
      parts.unshift({
        inlineData: {
          mimeType: 'image/jpeg', // Assuming jpeg/png generic handling
          data: cleanBase64
        }
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts },
      config: {
        temperature: 0.4,
        systemInstruction: systemInstruction
      }
    });

    return response.text || "Uzr, ma'lumotni tahlil qila olmadim. Iltimos qaytadan urinib ko'ring.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Tizimda xatolik yuz berdi. Internet aloqasini tekshiring. (Agar rasm yuklagan bo'lsangiz, rasm hajmi juda katta bo'lishi mumkin).";
  }
};